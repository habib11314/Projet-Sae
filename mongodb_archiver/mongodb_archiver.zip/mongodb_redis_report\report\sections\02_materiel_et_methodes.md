# Matériel et Méthodes

Décrire le matériel utilisé (serveurs, versions MongoDB/Redis), les méthodes d'archivage, les métriques mesurées, et les scripts d'exécution.